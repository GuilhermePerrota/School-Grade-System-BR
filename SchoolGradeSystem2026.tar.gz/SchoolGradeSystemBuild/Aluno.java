package schoolgradesystem;

import java.util.ArrayList;
import java.util.List;

public class Aluno {
    private final int id;
    private final String nome;
    private final int anoLetivo;
    private final String serie;
    private final String turma;
    private final List<Double> notas;

    public Aluno(int id, String nome, int anoLetivo, String serie, String turma) {
        this.id = id;
        this.nome = nome;
        this.anoLetivo = anoLetivo;
        this.serie = serie;
        this.turma = turma;
        this.notas = new ArrayList<>();
    }

    public void adicionarNota(double nota) {
        if (nota < 0 || nota > 10) {
            throw new IllegalArgumentException("A nota deve estar entre 0 e 10.");
        }
        notas.add(nota);
    }

    public double calcularMedia() {
        if (notas.isEmpty()) return 0.0;
        double soma = 0;
        for (double nota : notas) soma += nota;
        return soma / notas.size();
    }

    public String getSituacao() {
        if (notas.isEmpty()) return "SEM NOTAS";
        return calcularMedia() >= 6.0 ? "APROVADO" : "REPROVADO";
    }

    public int getId() { return id; }
    public String getNome() { return nome; }
    public int getAnoLetivo() { return anoLetivo; }
    public String getSerie() { return serie; }
    public String getTurma() { return turma; }
    public List<Double> getNotas() { return new ArrayList<>(notas); }

    @Override
    public String toString() {
        return String.format("#%d | %-25s | %d | %s | Turma: %-8s | Média: %.2f | %s",
                id, nome, anoLetivo, serie, turma, calcularMedia(), getSituacao());
    }
}

package schoolgradesystem;

import javax.swing.*;
import java.awt.*;

public class Login extends JFrame {
    private JTextField campoUsuario;
    private JPasswordField campoSenha;

    public Login() {
        setTitle("School Grade System - Login");
        setSize(430, 330);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setResizable(false);

        JPanel painel = new JPanel();
        painel.setLayout(new BoxLayout(painel, BoxLayout.Y_AXIS));
        painel.setBorder(BorderFactory.createEmptyBorder(30, 45, 30, 45));
        painel.setBackground(new Color(15, 23, 42));

        JLabel titulo = new JLabel("School Grade System");
        titulo.setForeground(Color.WHITE);
        titulo.setFont(new Font("SansSerif", Font.BOLD, 26));
        titulo.setAlignmentX(Component.CENTER_ALIGNMENT);

        JLabel subtitulo = new JLabel("Acesso do administrador");
        subtitulo.setForeground(new Color(148, 163, 184));
        subtitulo.setAlignmentX(Component.CENTER_ALIGNMENT);

        JLabel usuarioLabel = new JLabel("Usuário");
        usuarioLabel.setForeground(Color.WHITE);
        usuarioLabel.setAlignmentX(Component.LEFT_ALIGNMENT);

        campoUsuario = new JTextField();
        campoUsuario.setMaximumSize(new Dimension(Integer.MAX_VALUE, 36));

        JLabel senhaLabel = new JLabel("Senha");
        senhaLabel.setForeground(Color.WHITE);
        senhaLabel.setAlignmentX(Component.LEFT_ALIGNMENT);

        campoSenha = new JPasswordField();
        campoSenha.setMaximumSize(new Dimension(Integer.MAX_VALUE, 36));

        JButton entrar = new JButton("Entrar");
        entrar.setAlignmentX(Component.CENTER_ALIGNMENT);
        entrar.setFocusPainted(false);
        entrar.addActionListener(e -> fazerLogin());

        // Deixa o Enter funcionando para entrar também
        campoSenha.addActionListener(e -> fazerLogin());

        painel.add(titulo);
        painel.add(Box.createVerticalStrut(5));
        painel.add(subtitulo);
        painel.add(Box.createVerticalStrut(22));
        painel.add(usuarioLabel);
        painel.add(Box.createVerticalStrut(5));
        painel.add(campoUsuario);
        painel.add(Box.createVerticalStrut(12));
        painel.add(senhaLabel);
        painel.add(Box.createVerticalStrut(5));
        painel.add(campoSenha);
        painel.add(Box.createVerticalStrut(18));
        painel.add(entrar);

        add(painel);
    }

    private void fazerLogin() {
        String usuario = campoUsuario.getText().trim();
        String senha = new String(campoSenha.getPassword());

        // Aqui eu verifico se o usuário e a senha estão certos
        if (usuario.equals("admin") && senha.equals("1234")) {
            dispose();

            // Se estiver certo, abre o sistema principal
            new Main().setVisible(true);
        } else {
            JOptionPane.showMessageDialog(
                    this,
                    "Usuário ou senha incorretos.",
                    "Erro",
                    JOptionPane.ERROR_MESSAGE
            );
            campoSenha.setText("");
            campoUsuario.requestFocus();
        }
    }
}

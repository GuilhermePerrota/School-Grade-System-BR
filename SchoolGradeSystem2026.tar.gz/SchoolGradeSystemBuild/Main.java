package schoolgradesystem;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

public class Main extends JFrame {
    private final SistemaEscolar sistema = new SistemaEscolar();
    private final DefaultTableModel tableModel;
    private final JTable tabela;

    private final JLabel totalLabel = new JLabel("0");
    private final JLabel aprovadosLabel = new JLabel("0");
    private final JLabel reprovadosLabel = new JLabel("0");
    private final JLabel mediaLabel = new JLabel("0.00");
    private final JComboBox<String> filtroAnoLetivo =
            new JComboBox<>(new String[]{"Todos", "2026", "2027", "2028", "2029", "2030"});
    private final JComboBox<String> filtroSerie =
            new JComboBox<>(new String[]{"Todas", "1º Ano", "2º Ano", "3º Ano"});

    public Main() {
        setTitle("School Grade System");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setMinimumSize(new Dimension(1100, 700));
        setLocationRelativeTo(null);

        JPanel root = new JPanel(new BorderLayout(18, 18));
        root.setBorder(new EmptyBorder(24, 24, 24, 24));
        root.setBackground(new Color(15, 23, 42));
        setContentPane(root);

        root.add(criarCabecalho(), BorderLayout.NORTH);

        tableModel = new DefaultTableModel(
                new Object[]{"ID", "Aluno", "Ano letivo", "Série", "Turma", "Notas", "Média", "Situação"}, 0) {
            @Override public boolean isCellEditable(int row, int column) { return false; }
        };

        tabela = new JTable(tableModel);
        tabela.setRowHeight(38);
        tabela.setFont(new Font("SansSerif", Font.PLAIN, 14));
        tabela.getTableHeader().setFont(new Font("SansSerif", Font.BOLD, 13));
        tabela.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

        JScrollPane scroll = new JScrollPane(tabela);
        scroll.setBorder(BorderFactory.createEmptyBorder());
        root.add(scroll, BorderLayout.CENTER);

        root.add(criarPainelInferior(), BorderLayout.SOUTH);

        filtroAnoLetivo.addActionListener(e -> atualizarTabela());
        filtroSerie.addActionListener(e -> atualizarTabela());
        atualizarTabela();
    }

    private JPanel criarCabecalho() {
        JPanel header = new JPanel(new BorderLayout(20, 0));
        header.setOpaque(false);

        JPanel textos = new JPanel();
        textos.setOpaque(false);
        textos.setLayout(new BoxLayout(textos, BoxLayout.Y_AXIS));

        JLabel titulo = new JLabel("School Grade System");
        titulo.setForeground(Color.WHITE);
        titulo.setFont(new Font("SansSerif", Font.BOLD, 32));

        JLabel subtitulo = new JLabel("Gestão de alunos, notas e desempenho por ano escolar");
        subtitulo.setForeground(new Color(148, 163, 184));
        subtitulo.setFont(new Font("SansSerif", Font.PLAIN, 15));

        textos.add(titulo);
        textos.add(Box.createVerticalStrut(6));
        textos.add(subtitulo);
        textos.add(Box.createVerticalStrut(15));

        JPanel filtro = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 0));
        filtro.setOpaque(false);
        JLabel labelAno = new JLabel("Ano letivo:");
        JLabel labelSerie = new JLabel("Série:");
        for (JLabel label : new JLabel[]{labelAno, labelSerie}) {
            label.setForeground(new Color(203, 213, 225));
            label.setFont(new Font("SansSerif", Font.BOLD, 13));
        }
        filtroAnoLetivo.setFont(new Font("SansSerif", Font.PLAIN, 13));
        filtroSerie.setFont(new Font("SansSerif", Font.PLAIN, 13));
        filtro.add(labelAno);
        filtro.add(filtroAnoLetivo);
        filtro.add(Box.createHorizontalStrut(10));
        filtro.add(labelSerie);
        filtro.add(filtroSerie);
        textos.add(filtro);

        header.add(textos, BorderLayout.WEST);

        JPanel stats = new JPanel(new GridLayout(1, 4, 9, 0));
        stats.setOpaque(false);
        stats.add(statCard("ALUNOS", totalLabel));
        stats.add(statCard("APROVADOS", aprovadosLabel));
        stats.add(statCard("REPROVADOS", reprovadosLabel));
        stats.add(statCard("MÉDIA GERAL", mediaLabel));
        header.add(stats, BorderLayout.EAST);

        return header;
    }

    private JPanel statCard(String title, JLabel value) {
        JPanel card = new JPanel();
        card.setBackground(new Color(30, 41, 59));
        card.setBorder(new EmptyBorder(10, 18, 10, 18));
        card.setLayout(new BoxLayout(card, BoxLayout.Y_AXIS));

        JLabel t = new JLabel(title);
        t.setForeground(new Color(148, 163, 184));
        t.setFont(new Font("SansSerif", Font.BOLD, 10));
        value.setForeground(Color.WHITE);
        value.setFont(new Font("SansSerif", Font.BOLD, 21));

        card.add(t);
        card.add(value);
        return card;
    }

    private JPanel criarPainelInferior() {
        JPanel bottom = new JPanel(new FlowLayout(FlowLayout.LEFT, 9, 0));
        bottom.setOpaque(false);

        JButton cadastrar = botao("＋ Cadastrar aluno");
        JButton nota = botao("＋ Adicionar nota");
        JButton consultar = botao("🔎 Consultar");
        JButton relatorio = botao("▤ Relatório");
        JButton remover = botao("− Remover");

        cadastrar.addActionListener(e -> cadastrarAluno());
        nota.addActionListener(e -> adicionarNota());
        consultar.addActionListener(e -> consultarAluno());
        relatorio.addActionListener(e -> mostrarRelatorio());
        remover.addActionListener(e -> removerAluno());

        bottom.add(cadastrar);
        bottom.add(nota);
        bottom.add(consultar);
        bottom.add(relatorio);
        bottom.add(remover);

        return bottom;
    }

    private JButton botao(String texto) {
        JButton b = new JButton(texto);
        b.setFocusPainted(false);
        b.setFont(new Font("SansSerif", Font.BOLD, 13));
        b.setForeground(Color.WHITE);
        b.setBackground(new Color(37, 99, 235));
        b.setBorder(new EmptyBorder(12, 18, 12, 18));
        return b;
    }

    private void cadastrarAluno() {
        JTextField id = new JTextField();
        JTextField nome = new JTextField();
        JComboBox<String> ano = new JComboBox<>(new String[]{"2026", "2027", "2028", "2029", "2030"});
        JComboBox<String> serie = new JComboBox<>(new String[]{"1º Ano", "2º Ano", "3º Ano"});
        JTextField turma = new JTextField();

        JPanel p = new JPanel(new GridLayout(0, 1, 5, 5));
        p.add(new JLabel("ID:")); p.add(id);
        p.add(new JLabel("Nome:")); p.add(nome);
        p.add(new JLabel("Ano letivo:")); p.add(ano);
        p.add(new JLabel("Série do Ensino Médio:")); p.add(serie);
        p.add(new JLabel("Turma:")); p.add(turma);

        if (JOptionPane.showConfirmDialog(this, p, "Cadastrar aluno",
                JOptionPane.OK_CANCEL_OPTION) != JOptionPane.OK_OPTION) return;

        try {
            int idNum = Integer.parseInt(id.getText().trim());

            if (sistema.buscarPorId(idNum) != null) {
                erro("Já existe um aluno com esse ID.");
                return;
            }

            if (nome.getText().isBlank() || turma.getText().isBlank()) {
                erro("Nome e turma são obrigatórios.");
                return;
            }

            sistema.cadastrarAluno(new Aluno(
                    idNum, nome.getText().trim(), Integer.parseInt((String) ano.getSelectedItem()),
                    (String) serie.getSelectedItem(), turma.getText().trim()));

            atualizarTabela();
        } catch (NumberFormatException ex) {
            erro("Digite um ID numérico válido.");
        }
    }

    private void adicionarNota() {
        int id = selecionarId("ID do aluno:");
        if (id == -1) return;

        String entrada = JOptionPane.showInputDialog(this,
                "Nota (0 a 10):", "Adicionar nota", JOptionPane.PLAIN_MESSAGE);
        if (entrada == null) return;

        try {
            double nota = Double.parseDouble(entrada.replace(',', '.'));
            Aluno aluno = sistema.buscarPorId(id);

            if (aluno == null) {
                erro("Aluno não encontrado.");
                return;
            }

            aluno.adicionarNota(nota);
            atualizarTabela();
        } catch (NumberFormatException ex) {
            erro("Digite uma nota válida.");
        } catch (IllegalArgumentException ex) {
            erro(ex.getMessage());
        }
    }

    private void consultarAluno() {
        int id = selecionarId("ID do aluno:");
        if (id == -1) return;

        Aluno aluno = sistema.buscarPorId(id);
        if (aluno == null) {
            erro("Aluno não encontrado.");
            return;
        }

        String mensagem = String.format(
                "<html><h2>%s</h2><b>Ano letivo:</b> %d<br><b>Série:</b> %s<br><b>Turma:</b> %s<br>" +
                "<b>Notas:</b> %s<br><b>Média:</b> %.2f<br>" +
                "<b>Situação:</b> %s</html>",
                aluno.getNome(), aluno.getAnoLetivo(), aluno.getSerie(), aluno.getTurma(),
                aluno.getNotas(), aluno.calcularMedia(), aluno.getSituacao());

        JOptionPane.showMessageDialog(this, mensagem,
                "Desempenho do aluno", JOptionPane.INFORMATION_MESSAGE);
    }

    private void mostrarRelatorio() {
        String anoSelecionado = (String) filtroAnoLetivo.getSelectedItem();
        String serieSelecionada = (String) filtroSerie.getSelectedItem();
        int ano = anoSelecionado.equals("Todos") ? 0 : Integer.parseInt(anoSelecionado);
        List<Aluno> lista = sistema.filtrar(ano, serieSelecionada);
        String periodo = anoSelecionado.equals("Todos") ? "Todos os anos" : anoSelecionado;

        long aprovados = sistema.contarAprovados(lista);
        long reprovados = sistema.contarReprovados(lista);
        double media = sistema.calcularMedia(lista);

        StringBuilder texto = new StringBuilder();
        texto.append("<html><div style='width:520px'>");
        texto.append("<h2>Relatório — ").append(periodo).append("</h2>");
        texto.append("<b>Série:</b> ").append(serieSelecionada).append("<br>");
        texto.append("<b>Total de alunos:</b> ").append(lista.size()).append("<br>");
        texto.append("<b>Aprovados:</b> ").append(aprovados).append("<br>");
        texto.append("<b>Reprovados:</b> ").append(reprovados).append("<br>");
        texto.append("<b>Média geral:</b> ").append(String.format("%.2f", media)).append("<br><br>");

        if (lista.isEmpty()) {
            texto.append("Nenhum aluno cadastrado neste período.");
        } else {
            texto.append("<b>Desempenho:</b><br>");
            for (Aluno aluno : lista) {
                texto.append("• ").append(aluno.getNome())
                        .append(" — ").append(String.format("%.2f", aluno.calcularMedia()))
                        .append(" — ").append(aluno.getSituacao()).append("<br>");
            }
        }

        texto.append("</div></html>");

        JOptionPane.showMessageDialog(this, texto.toString(),
                "Relatório acadêmico", JOptionPane.INFORMATION_MESSAGE);
    }

    private void removerAluno() {
        int row = tabela.getSelectedRow();
        int id;

        if (row >= 0) id = (int) tableModel.getValueAt(row, 0);
        else {
            id = selecionarId("ID do aluno:");
            if (id == -1) return;
        }

        if (JOptionPane.showConfirmDialog(this,
                "Remover o aluno selecionado?", "Confirmar",
                JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION) {
            sistema.removerAluno(id);
            atualizarTabela();
        }
    }

    private int selecionarId(String mensagem) {
        String entrada = JOptionPane.showInputDialog(this, mensagem);
        if (entrada == null) return -1;

        try {
            return Integer.parseInt(entrada.trim());
        } catch (NumberFormatException e) {
            erro("Digite um ID válido.");
            return -1;
        }
    }

    private void atualizarTabela() {
        tableModel.setRowCount(0);

        String anoSelecionado = (String) filtroAnoLetivo.getSelectedItem();
        String serieSelecionada = (String) filtroSerie.getSelectedItem();
        int ano = anoSelecionado.equals("Todos") ? 0 : Integer.parseInt(anoSelecionado);
        List<Aluno> alunos = sistema.filtrar(ano, serieSelecionada);

        for (Aluno aluno : alunos) {
            tableModel.addRow(new Object[]{
                    aluno.getId(), aluno.getNome(), aluno.getAnoLetivo(), aluno.getSerie(), aluno.getTurma(),
                    aluno.getNotas(), String.format("%.2f", aluno.calcularMedia()),
                    aluno.getSituacao()
            });
        }

        totalLabel.setText(String.valueOf(alunos.size()));
        aprovadosLabel.setText(String.valueOf(sistema.contarAprovados(alunos)));
        reprovadosLabel.setText(String.valueOf(sistema.contarReprovados(alunos)));
        mediaLabel.setText(String.format("%.2f", sistema.calcularMedia(alunos)));
    }

    private void erro(String mensagem) {
        JOptionPane.showMessageDialog(this, mensagem,
                "Atenção", JOptionPane.WARNING_MESSAGE);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            try {
                UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
            } catch (Exception ignored) {}

            // Primeiro aparece a tela de login
            new Login().setVisible(true);
        });
    }
}

package schoolgradesystem;

import java.util.ArrayList;
import java.util.List;

public class SistemaEscolar {
    private final List<Aluno> alunos = new ArrayList<>();

    public void cadastrarAluno(Aluno aluno) {
        alunos.add(aluno);
    }

    public Aluno buscarPorId(int id) {
        for (Aluno aluno : alunos) {
            if (aluno.getId() == id) return aluno;
        }
        return null;
    }

    public boolean removerAluno(int id) {
        Aluno aluno = buscarPorId(id);
        return aluno != null && alunos.remove(aluno);
    }

    public List<Aluno> getAlunos() {
        return new ArrayList<>(alunos);
    }

    public List<Aluno> filtrar(int anoLetivo, String serie) {
        List<Aluno> resultado = new ArrayList<>();
        for (Aluno aluno : alunos) {
            boolean anoOk = anoLetivo == 0 || aluno.getAnoLetivo() == anoLetivo;
            boolean serieOk = serie.equals("Todas") || aluno.getSerie().equals(serie);
            if (anoOk && serieOk) resultado.add(aluno);
        }
        return resultado;
    }

    public double calcularMediaGeral() {
        return calcularMedia(getAlunos());
    }

    public double calcularMedia(List<Aluno> lista) {
        double soma = 0;
        int quantidade = 0;

        for (Aluno aluno : lista) {
            for (double nota : aluno.getNotas()) {
                soma += nota;
                quantidade++;
            }
        }
        return quantidade == 0 ? 0.0 : soma / quantidade;
    }

    public long contarAprovados(List<Aluno> lista) {
        return lista.stream().filter(a -> a.getSituacao().equals("APROVADO")).count();
    }

    public long contarReprovados(List<Aluno> lista) {
        return lista.stream().filter(a -> a.getSituacao().equals("REPROVADO")).count();
    }

    public long contarAprovados() { return contarAprovados(alunos); }
    public long contarReprovados() { return contarReprovados(alunos); }
}
